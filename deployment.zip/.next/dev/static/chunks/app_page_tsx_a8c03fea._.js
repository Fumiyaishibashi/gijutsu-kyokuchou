(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_77cdb6c6._.js",
  "static/chunks/app_3424453f._.js"
],
    source: "dynamic"
});
