(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/ImageInputSelector.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ImageInputSelector
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
'use client';
;
;
function ImageInputSelector(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(14);
    if ($[0] !== "56782e25fad4cff19282eb70cea5a852ce265e9f807d44553fab60d567aaf5e4") {
        for(let $i = 0; $i < 14; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "56782e25fad4cff19282eb70cea5a852ce265e9f807d44553fab60d567aaf5e4";
    }
    const { mode, onModeChange } = t0;
    let t1;
    if ($[1] !== onModeChange) {
        t1 = ({
            "ImageInputSelector[<button>.onClick]": ()=>onModeChange("camera")
        })["ImageInputSelector[<button>.onClick]"];
        $[1] = onModeChange;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const t2 = `flex-1 px-4 py-2 rounded-md font-medium transition-colors ${mode === "camera" ? "bg-sky-500 text-white" : "bg-slate-700 text-slate-300 hover:bg-slate-600"}`;
    let t3;
    if ($[3] !== t1 || $[4] !== t2) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t1,
            className: t2,
            children: "📸 カメラ"
        }, void 0, false, {
            fileName: "[project]/app/components/ImageInputSelector.tsx",
            lineNumber: 39,
            columnNumber: 10
        }, this);
        $[3] = t1;
        $[4] = t2;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    let t4;
    if ($[6] !== onModeChange) {
        t4 = ({
            "ImageInputSelector[<button>.onClick]": ()=>onModeChange("upload")
        })["ImageInputSelector[<button>.onClick]"];
        $[6] = onModeChange;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const t5 = `flex-1 px-4 py-2 rounded-md font-medium transition-colors ${mode === "upload" ? "bg-sky-500 text-white" : "bg-slate-700 text-slate-300 hover:bg-slate-600"}`;
    let t6;
    if ($[8] !== t4 || $[9] !== t5) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: t4,
            className: t5,
            children: "📁 アップロード"
        }, void 0, false, {
            fileName: "[project]/app/components/ImageInputSelector.tsx",
            lineNumber: 59,
            columnNumber: 10
        }, this);
        $[8] = t4;
        $[9] = t5;
        $[10] = t6;
    } else {
        t6 = $[10];
    }
    let t7;
    if ($[11] !== t3 || $[12] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-2 p-2 bg-slate-800/90 rounded-lg",
            children: [
                t3,
                t6
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ImageInputSelector.tsx",
            lineNumber: 68,
            columnNumber: 10
        }, this);
        $[11] = t3;
        $[12] = t6;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    return t7;
}
_c = ImageInputSelector;
var _c;
__turbopack_context__.k.register(_c, "ImageInputSelector");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/CameraCapture.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CameraCapture
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$webcam$2f$dist$2f$react$2d$webcam$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-webcam/dist/react-webcam.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function CameraCapture(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(19);
    if ($[0] !== "c0c413d6ef7b6d8c51ffcf76350dee9856a08445e21e96820ae702d35dc9cc90") {
        for(let $i = 0; $i < 19; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c0c413d6ef7b6d8c51ffcf76350dee9856a08445e21e96820ae702d35dc9cc90";
    }
    const { onCapture, onError } = t0;
    const webcamRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [hasPermission, setHasPermission] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    let t1;
    if ($[1] !== onError) {
        t1 = ({
            "CameraCapture[handleUserMediaError]": (error)=>{
                console.error("\u30AB\u30E1\u30E9\u30A2\u30AF\u30BB\u30B9\u30A8\u30E9\u30FC:", error);
                setHasPermission(false);
                onError(new Error("\u30AB\u30E1\u30E9\u3078\u306E\u30A2\u30AF\u30BB\u30B9\u304C\u62D2\u5426\u3055\u308C\u307E\u3057\u305F\u3002\u8A2D\u5B9A\u304B\u3089\u30AB\u30E1\u30E9\u6A29\u9650\u3092\u8A31\u53EF\u3057\u3066\u304F\u3060\u3055\u3044"));
            }
        })["CameraCapture[handleUserMediaError]"];
        $[1] = onError;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const handleUserMediaError = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "CameraCapture[handleUserMedia]": ()=>{
                setHasPermission(true);
            }
        })["CameraCapture[handleUserMedia]"];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const handleUserMedia = t2;
    let t3;
    if ($[4] !== onCapture || $[5] !== onError) {
        t3 = ({
            "CameraCapture[capture]": ()=>{
                const imageSrc = webcamRef.current?.getScreenshot();
                if (imageSrc) {
                    fetch(imageSrc).then(_CameraCaptureCaptureAnonymous).then({
                        "CameraCapture[capture > (anonymous)()]": (blob)=>{
                            onCapture(blob);
                        }
                    }["CameraCapture[capture > (anonymous)()]"]).catch({
                        "CameraCapture[capture > (anonymous)()]": (error_0)=>{
                            console.error("\u753B\u50CF\u5909\u63DB\u30A8\u30E9\u30FC:", error_0);
                            onError(error_0);
                        }
                    }["CameraCapture[capture > (anonymous)()]"]);
                }
            }
        })["CameraCapture[capture]"];
        $[4] = onCapture;
        $[5] = onError;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    const capture = t3;
    let t4;
    if ($[7] !== hasPermission) {
        t4 = hasPermission === false && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 flex items-center justify-center bg-slate-900/90 z-10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-6 max-w-md",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-6xl mb-4",
                        children: "📷"
                    }, void 0, false, {
                        fileName: "[project]/app/components/CameraCapture.tsx",
                        lineNumber: 84,
                        columnNumber: 167
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-xl font-bold text-slate-50 mb-2",
                        children: "カメラアクセスが必要です"
                    }, void 0, false, {
                        fileName: "[project]/app/components/CameraCapture.tsx",
                        lineNumber: 84,
                        columnNumber: 206
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-slate-300 mb-4",
                        children: "機器を撮影するには、カメラへのアクセスを許可してください。"
                    }, void 0, false, {
                        fileName: "[project]/app/components/CameraCapture.tsx",
                        lineNumber: 84,
                        columnNumber: 276
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-slate-400",
                        children: "ブラウザの設定からカメラ権限を有効にするか、アップロードモードをご利用ください。"
                    }, void 0, false, {
                        fileName: "[project]/app/components/CameraCapture.tsx",
                        lineNumber: 84,
                        columnNumber: 344
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/CameraCapture.tsx",
                lineNumber: 84,
                columnNumber: 125
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/CameraCapture.tsx",
            lineNumber: 84,
            columnNumber: 37
        }, this);
        $[7] = hasPermission;
        $[8] = t4;
    } else {
        t4 = $[8];
    }
    let t5;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = {
            facingMode: "environment",
            width: {
                ideal: 1920
            },
            height: {
                ideal: 1080
            }
        };
        $[9] = t5;
    } else {
        t5 = $[9];
    }
    let t6;
    if ($[10] !== handleUserMediaError) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$webcam$2f$dist$2f$react$2d$webcam$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref: webcamRef,
            audio: false,
            screenshotFormat: "image/jpeg",
            screenshotQuality: 0.9,
            videoConstraints: t5,
            onUserMedia: handleUserMedia,
            onUserMediaError: handleUserMediaError,
            className: "w-full h-full object-contain"
        }, void 0, false, {
            fileName: "[project]/app/components/CameraCapture.tsx",
            lineNumber: 107,
            columnNumber: 10
        }, this);
        $[10] = handleUserMediaError;
        $[11] = t6;
    } else {
        t6 = $[11];
    }
    let t7;
    if ($[12] !== capture || $[13] !== hasPermission) {
        t7 = hasPermission && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: capture,
            className: "absolute bottom-8 left-1/2 transform -translate-x-1/2 w-16 h-16 bg-sky-500 hover:bg-sky-600 rounded-full shadow-lg transition-all hover:scale-110 active:scale-95 flex items-center justify-center",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-12 h-12 bg-white rounded-full"
            }, void 0, false, {
                fileName: "[project]/app/components/CameraCapture.tsx",
                lineNumber: 115,
                columnNumber: 260
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/CameraCapture.tsx",
            lineNumber: 115,
            columnNumber: 27
        }, this);
        $[12] = capture;
        $[13] = hasPermission;
        $[14] = t7;
    } else {
        t7 = $[14];
    }
    let t8;
    if ($[15] !== t4 || $[16] !== t6 || $[17] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative w-full h-full flex flex-col items-center justify-center",
            children: [
                t4,
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/CameraCapture.tsx",
            lineNumber: 124,
            columnNumber: 10
        }, this);
        $[15] = t4;
        $[16] = t6;
        $[17] = t7;
        $[18] = t8;
    } else {
        t8 = $[18];
    }
    return t8;
}
_s(CameraCapture, "Olg88de08UYlCyD0C0tt+nUlWZo=");
_c = CameraCapture;
function _CameraCaptureCaptureAnonymous(res) {
    return res.blob();
}
var _c;
__turbopack_context__.k.register(_c, "CameraCapture");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/FileUpload.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FileSizeError",
    ()=>FileSizeError,
    "UnsupportedFormatError",
    ()=>UnsupportedFormatError,
    "default",
    ()=>FileUpload
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
// カスタムエラークラス
class FileSizeError extends Error {
    constructor(message){
        super(message);
        this.name = 'FileSizeError';
    }
}
class UnsupportedFormatError extends Error {
    constructor(message){
        super(message);
        this.name = 'UnsupportedFormatError';
    }
}
function FileUpload({ onFileSelect, onError, maxSizeBytes = 10 * 1024 * 1024 // デフォルト10MB
 }) {
    _s();
    const [isDragging, setIsDragging] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // ファイル検証
    const validateFile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FileUpload.useCallback[validateFile]": (file)=>{
            const ALLOWED_TYPES = [
                'image/jpeg',
                'image/png',
                'image/webp'
            ];
            // ファイルサイズチェック
            if (file.size > maxSizeBytes) {
                throw new FileSizeError(`画像サイズが大きすぎます。${Math.round(maxSizeBytes / 1024 / 1024)}MB以下の画像を選択してください`);
            }
            // ファイル形式チェック
            if (!ALLOWED_TYPES.includes(file.type)) {
                throw new UnsupportedFormatError('対応していない画像形式です。JPEG、PNG、またはWEBP形式の画像を選択してください');
            }
        }
    }["FileUpload.useCallback[validateFile]"], [
        maxSizeBytes
    ]);
    // ファイル選択ハンドラ
    const handleFileChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FileUpload.useCallback[handleFileChange]": (event)=>{
            const file_0 = event.target.files?.[0];
            if (file_0) {
                try {
                    validateFile(file_0);
                    onFileSelect(file_0);
                } catch (error) {
                    onError(error);
                }
            }
        }
    }["FileUpload.useCallback[handleFileChange]"], [
        validateFile,
        onFileSelect,
        onError
    ]);
    // ドラッグ&ドロップハンドラ
    const handleDragOver = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FileUpload.useCallback[handleDragOver]": (event_0)=>{
            event_0.preventDefault();
            setIsDragging(true);
        }
    }["FileUpload.useCallback[handleDragOver]"], []);
    const handleDragLeave = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FileUpload.useCallback[handleDragLeave]": (event_1)=>{
            event_1.preventDefault();
            setIsDragging(false);
        }
    }["FileUpload.useCallback[handleDragLeave]"], []);
    const handleDrop = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "FileUpload.useCallback[handleDrop]": (event_2)=>{
            event_2.preventDefault();
            setIsDragging(false);
            const file_1 = event_2.dataTransfer.files[0];
            if (file_1) {
                try {
                    validateFile(file_1);
                    onFileSelect(file_1);
                } catch (error_0) {
                    onError(error_0);
                }
            }
        }
    }["FileUpload.useCallback[handleDrop]"], [
        validateFile,
        onFileSelect,
        onError
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full h-full flex items-center justify-center p-8",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
            onDragOver: handleDragOver,
            onDragLeave: handleDragLeave,
            onDrop: handleDrop,
            className: `
          w-full max-w-2xl h-96 
          border-4 border-dashed rounded-2xl
          flex flex-col items-center justify-center
          cursor-pointer transition-all
          ${isDragging ? 'border-sky-500 bg-sky-500/10' : 'border-slate-600 hover:border-slate-500 bg-slate-800/50 hover:bg-slate-800/70'}
        `,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "file",
                    accept: "image/jpeg,image/png,image/webp",
                    onChange: handleFileChange,
                    className: "hidden"
                }, void 0, false, {
                    fileName: "[project]/app/components/FileUpload.tsx",
                    lineNumber: 93,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-6xl mb-4",
                            children: isDragging ? '📥' : '📁'
                        }, void 0, false, {
                            fileName: "[project]/app/components/FileUpload.tsx",
                            lineNumber: 96,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "text-xl font-bold text-slate-50 mb-2",
                            children: isDragging ? 'ここにドロップ' : '画像を選択'
                        }, void 0, false, {
                            fileName: "[project]/app/components/FileUpload.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-slate-300 mb-4",
                            children: "クリックして画像を選択、またはドラッグ&ドロップ"
                        }, void 0, false, {
                            fileName: "[project]/app/components/FileUpload.tsx",
                            lineNumber: 102,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-sm text-slate-400 space-y-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: "対応形式: JPEG, PNG, WEBP"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/FileUpload.tsx",
                                    lineNumber: 106,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    children: [
                                        "最大サイズ: ",
                                        Math.round(maxSizeBytes / 1024 / 1024),
                                        "MB"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/FileUpload.tsx",
                                    lineNumber: 107,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/FileUpload.tsx",
                            lineNumber: 105,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/FileUpload.tsx",
                    lineNumber: 95,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/FileUpload.tsx",
            lineNumber: 86,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/FileUpload.tsx",
        lineNumber: 85,
        columnNumber: 10
    }, this);
}
_s(FileUpload, "G57ylOccUc3YziRsxLjGUk2/d8U=");
_c = FileUpload;
;
var _c;
__turbopack_context__.k.register(_c, "FileUpload");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ImagePreview.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ImagePreview
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
'use client';
;
;
;
function ImagePreview(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(13);
    if ($[0] !== "386e65f45cc25b8797a521cb4e896399cb4643b192a307d46e252454fdafe1a4") {
        for(let $i = 0; $i < 13; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "386e65f45cc25b8797a521cb4e896399cb4643b192a307d46e252454fdafe1a4";
    }
    const { imageUrl, onConfirm, onRetake } = t0;
    let t1;
    if ($[1] !== imageUrl) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 relative flex items-center justify-center bg-slate-900 p-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full h-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: imageUrl,
                    alt: "\u30D7\u30EC\u30D3\u30E5\u30FC",
                    fill: true,
                    className: "object-contain",
                    priority: true
                }, void 0, false, {
                    fileName: "[project]/app/components/ImagePreview.tsx",
                    lineNumber: 30,
                    columnNumber: 133
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/ImagePreview.tsx",
                lineNumber: 30,
                columnNumber: 93
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ImagePreview.tsx",
            lineNumber: 30,
            columnNumber: 10
        }, this);
        $[1] = imageUrl;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    let t2;
    if ($[3] !== onRetake) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: onRetake,
            className: "flex-1 px-6 py-3 bg-slate-700 hover:bg-slate-600 text-slate-50 font-medium rounded-lg transition-colors",
            children: "🔄 撮り直す"
        }, void 0, false, {
            fileName: "[project]/app/components/ImagePreview.tsx",
            lineNumber: 38,
            columnNumber: 10
        }, this);
        $[3] = onRetake;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== onConfirm) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: onConfirm,
            className: "flex-1 px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors",
            children: "✓ 分析する"
        }, void 0, false, {
            fileName: "[project]/app/components/ImagePreview.tsx",
            lineNumber: 46,
            columnNumber: 10
        }, this);
        $[5] = onConfirm;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== t2 || $[8] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex gap-4 p-4 bg-slate-800/90",
            children: [
                t2,
                t3
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ImagePreview.tsx",
            lineNumber: 54,
            columnNumber: 10
        }, this);
        $[7] = t2;
        $[8] = t3;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] !== t1 || $[11] !== t4) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-full flex flex-col",
            children: [
                t1,
                t4
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ImagePreview.tsx",
            lineNumber: 63,
            columnNumber: 10
        }, this);
        $[10] = t1;
        $[11] = t4;
        $[12] = t5;
    } else {
        t5 = $[12];
    }
    return t5;
}
_c = ImagePreview;
var _c;
__turbopack_context__.k.register(_c, "ImagePreview");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/types/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * 技術局長 - 型定義
 */ // リスクレベル
__turbopack_context__.s([
    "RISK_COLORS",
    ()=>RISK_COLORS
]);
const RISK_COLORS = {
    SAFE: '#10B981',
    WARNING: '#F59E0B',
    DANGER: '#EF4444',
    UNKNOWN: '#0EA5E9' // Sky-500
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/OverlayRenderer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OverlayRenderer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$types$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/types/index.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
function OverlayRenderer(t0) {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(25);
    if ($[0] !== "8d1deff37b023280e8cec97e9c4fa72a550a8c77c4105ed4a8e7c895fec9aefd") {
        for(let $i = 0; $i < 25; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "8d1deff37b023280e8cec97e9c4fa72a550a8c77c4105ed4a8e7c895fec9aefd";
    }
    const { imageUrl, equipment, onEquipmentClick } = t0;
    const imageRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            width: 0,
            height: 0
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const [imageDimensions, setImageDimensions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t1);
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "OverlayRenderer[updateImageDimensions]": ()=>{
                if (imageRef.current) {
                    setImageDimensions({
                        width: imageRef.current.clientWidth,
                        height: imageRef.current.clientHeight
                    });
                }
            }
        })["OverlayRenderer[updateImageDimensions]"];
        $[2] = t2;
    } else {
        t2 = $[2];
    }
    const updateImageDimensions = t2;
    let t3;
    let t4;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = ({
            "OverlayRenderer[useEffect()]": ()=>{
                updateImageDimensions();
                window.addEventListener("resize", updateImageDimensions);
                return ()=>window.removeEventListener("resize", updateImageDimensions);
            }
        })["OverlayRenderer[useEffect()]"];
        t4 = [
            updateImageDimensions
        ];
        $[3] = t3;
        $[4] = t4;
    } else {
        t3 = $[3];
        t4 = $[4];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t3, t4);
    let t5;
    if ($[5] !== imageDimensions) {
        t5 = ({
            "OverlayRenderer[calculateBoundingBoxStyle]": (equipment_0)=>{
                const { bbox } = equipment_0;
                const { width, height } = imageDimensions;
                const left = bbox.x / 100 * width;
                const top = bbox.y / 100 * height;
                const boxWidth = bbox.width / 100 * width;
                const boxHeight = bbox.height / 100 * height;
                return {
                    position: "absolute",
                    left: `${left}px`,
                    top: `${top}px`,
                    width: `${boxWidth}px`,
                    height: `${boxHeight}px`,
                    border: `4px solid ${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$types$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RISK_COLORS"][equipment_0.risk_level]}`,
                    pointerEvents: "auto",
                    cursor: "pointer"
                };
            }
        })["OverlayRenderer[calculateBoundingBoxStyle]"];
        $[5] = imageDimensions;
        $[6] = t5;
    } else {
        t5 = $[6];
    }
    const calculateBoundingBoxStyle = t5;
    let t6;
    if ($[7] !== imageUrl) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            ref: imageRef,
            src: imageUrl,
            alt: "\u5206\u6790\u5BFE\u8C61\u753B\u50CF",
            fill: true,
            className: "object-contain",
            onLoad: updateImageDimensions,
            priority: true
        }, void 0, false, {
            fileName: "[project]/app/components/OverlayRenderer.tsx",
            lineNumber: 112,
            columnNumber: 10
        }, this);
        $[7] = imageUrl;
        $[8] = t6;
    } else {
        t6 = $[8];
    }
    let t7;
    if ($[9] !== calculateBoundingBoxStyle || $[10] !== equipment || $[11] !== imageDimensions.width || $[12] !== onEquipmentClick) {
        t7 = imageDimensions.width > 0 && equipment.map({
            "OverlayRenderer[equipment.map()]": (eq, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: calculateBoundingBoxStyle(eq),
                        onClick: {
                            "OverlayRenderer[equipment.map() > <div>.onClick]": ()=>onEquipmentClick(eq)
                        }["OverlayRenderer[equipment.map() > <div>.onClick]"],
                        className: "transition-all hover:opacity-80",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute -top-8 left-0 px-2 py-1 bg-black/75 text-white text-sm font-medium rounded whitespace-nowrap",
                            style: {
                                color: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$types$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RISK_COLORS"][eq.risk_level]
                            },
                            children: eq.name
                        }, void 0, false, {
                            fileName: "[project]/app/components/OverlayRenderer.tsx",
                            lineNumber: 123,
                            columnNumber: 108
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/OverlayRenderer.tsx",
                        lineNumber: 121,
                        columnNumber: 75
                    }, this)
                }, index, false, {
                    fileName: "[project]/app/components/OverlayRenderer.tsx",
                    lineNumber: 121,
                    columnNumber: 58
                }, this)
        }["OverlayRenderer[equipment.map()]"]);
        $[9] = calculateBoundingBoxStyle;
        $[10] = equipment;
        $[11] = imageDimensions.width;
        $[12] = onEquipmentClick;
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    let t8;
    if ($[14] !== t6 || $[15] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative w-full h-full",
            children: [
                t6,
                t7
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/OverlayRenderer.tsx",
            lineNumber: 137,
            columnNumber: 10
        }, this);
        $[14] = t6;
        $[15] = t7;
        $[16] = t8;
    } else {
        t8 = $[16];
    }
    let t9;
    if ($[17] !== equipment.length) {
        t9 = equipment.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute top-4 right-4 px-4 py-2 bg-black/75 text-white rounded-lg",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm font-medium",
                children: [
                    "検出: ",
                    equipment.length,
                    "個"
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/OverlayRenderer.tsx",
                lineNumber: 146,
                columnNumber: 118
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/OverlayRenderer.tsx",
            lineNumber: 146,
            columnNumber: 34
        }, this);
        $[17] = equipment.length;
        $[18] = t9;
    } else {
        t9 = $[18];
    }
    let t10;
    if ($[19] !== equipment.length) {
        t10 = equipment.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 flex items-center justify-center bg-slate-900/50",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center p-6 bg-slate-800/90 rounded-lg max-w-md",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-4xl mb-2",
                        children: "🔍"
                    }, void 0, false, {
                        fileName: "[project]/app/components/OverlayRenderer.tsx",
                        lineNumber: 154,
                        columnNumber: 189
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        className: "text-lg font-bold text-slate-50 mb-2",
                        children: "機器を認識できませんでした"
                    }, void 0, false, {
                        fileName: "[project]/app/components/OverlayRenderer.tsx",
                        lineNumber: 154,
                        columnNumber: 228
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-slate-300 text-sm",
                        children: "別の角度から撮影してください"
                    }, void 0, false, {
                        fileName: "[project]/app/components/OverlayRenderer.tsx",
                        lineNumber: 154,
                        columnNumber: 299
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/OverlayRenderer.tsx",
                lineNumber: 154,
                columnNumber: 120
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/OverlayRenderer.tsx",
            lineNumber: 154,
            columnNumber: 37
        }, this);
        $[19] = equipment.length;
        $[20] = t10;
    } else {
        t10 = $[20];
    }
    let t11;
    if ($[21] !== t10 || $[22] !== t8 || $[23] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative w-full h-full flex items-center justify-center bg-slate-900",
            children: [
                t8,
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/OverlayRenderer.tsx",
            lineNumber: 162,
            columnNumber: 11
        }, this);
        $[21] = t10;
        $[22] = t8;
        $[23] = t9;
        $[24] = t11;
    } else {
        t11 = $[24];
    }
    return t11;
}
_s(OverlayRenderer, "qZxxx/DFc4khAMomMI0n0/Ip92s=");
_c = OverlayRenderer;
var _c;
__turbopack_context__.k.register(_c, "OverlayRenderer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/EquipmentDetailModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EquipmentDetailModal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$types$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/types/index.ts [app-client] (ecmascript)");
'use client';
;
;
;
function EquipmentDetailModal(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(74);
    if ($[0] !== "36218dc5dcc23f4ded3cf3a9a13d87bb162c1fb8bbd2111f959254c3b266b5f5") {
        for(let $i = 0; $i < 74; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "36218dc5dcc23f4ded3cf3a9a13d87bb162c1fb8bbd2111f959254c3b266b5f5";
    }
    const { equipment, isOpen, onClose } = t0;
    if (!isOpen || !equipment) {
        return null;
    }
    let t1;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = {
            SAFE: {
                label: "\u5B89\u5168",
                icon: "\u2713",
                description: "\u5B89\u5168\u306B\u64CD\u4F5C\u3067\u304D\u307E\u3059"
            },
            WARNING: {
                label: "\u8B66\u544A",
                icon: "\u26A0\uFE0F",
                description: "\u78BA\u8A8D\u304C\u5FC5\u8981\u3067\u3059"
            },
            DANGER: {
                label: "\u5371\u967A",
                icon: "\u26D4",
                description: "\u89E6\u3089\u306A\u3044\u3067\u304F\u3060\u3055\u3044"
            },
            UNKNOWN: {
                label: "\u4E0D\u660E",
                icon: "\u2753",
                description: "\u8B58\u5225\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F"
            }
        };
        $[1] = t1;
    } else {
        t1 = $[1];
    }
    const riskInfo = t1;
    const info = riskInfo[equipment.risk_level];
    const t2 = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$types$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RISK_COLORS"][equipment.risk_level];
    let t3;
    if ($[2] !== t2) {
        t3 = {
            borderLeftColor: t2,
            borderLeftWidth: "4px"
        };
        $[2] = t2;
        $[3] = t3;
    } else {
        t3 = $[3];
    }
    let t4;
    if ($[4] !== info.icon) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-2xl",
            children: info.icon
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 75,
            columnNumber: 10
        }, this);
        $[4] = info.icon;
        $[5] = t4;
    } else {
        t4 = $[5];
    }
    const t5 = `${__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$types$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RISK_COLORS"][equipment.risk_level]}20`;
    const t6 = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$types$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RISK_COLORS"][equipment.risk_level];
    let t7;
    if ($[6] !== t5 || $[7] !== t6) {
        t7 = {
            backgroundColor: t5,
            color: t6
        };
        $[6] = t5;
        $[7] = t6;
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] !== info.label || $[10] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-sm font-bold px-2 py-1 rounded",
            style: t7,
            children: info.label
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 97,
            columnNumber: 10
        }, this);
        $[9] = info.label;
        $[10] = t7;
        $[11] = t8;
    } else {
        t8 = $[11];
    }
    let t9;
    if ($[12] !== t4 || $[13] !== t8) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center gap-2 mb-2",
            children: [
                t4,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 106,
            columnNumber: 10
        }, this);
        $[12] = t4;
        $[13] = t8;
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== equipment.name) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-xl font-bold text-slate-50",
            children: equipment.name
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 115,
            columnNumber: 11
        }, this);
        $[15] = equipment.name;
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    if ($[17] !== t10 || $[18] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1",
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 123,
            columnNumber: 11
        }, this);
        $[17] = t10;
        $[18] = t9;
        $[19] = t11;
    } else {
        t11 = $[19];
    }
    let t12;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            className: "w-6 h-6",
            fill: "none",
            stroke: "currentColor",
            viewBox: "0 0 24 24",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M6 18L18 6M6 6l12 12"
            }, void 0, false, {
                fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                lineNumber: 132,
                columnNumber: 90
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 132,
            columnNumber: 11
        }, this);
        $[20] = t12;
    } else {
        t12 = $[20];
    }
    let t13;
    if ($[21] !== onClose) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: onClose,
            className: "text-slate-400 hover:text-slate-200 transition-colors",
            children: t12
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 139,
            columnNumber: 11
        }, this);
        $[21] = onClose;
        $[22] = t13;
    } else {
        t13 = $[22];
    }
    let t14;
    if ($[23] !== t11 || $[24] !== t13) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-start justify-between",
            children: [
                t11,
                t13
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 147,
            columnNumber: 11
        }, this);
        $[23] = t11;
        $[24] = t13;
        $[25] = t14;
    } else {
        t14 = $[25];
    }
    let t15;
    if ($[26] !== t14 || $[27] !== t3) {
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6 border-b border-slate-700",
            style: t3,
            children: t14
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 156,
            columnNumber: 11
        }, this);
        $[26] = t14;
        $[27] = t3;
        $[28] = t15;
    } else {
        t15 = $[28];
    }
    let t16;
    if ($[29] === Symbol.for("react.memo_cache_sentinel")) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-sm font-medium text-slate-400 mb-2",
            children: "説明"
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 165,
            columnNumber: 11
        }, this);
        $[29] = t16;
    } else {
        t16 = $[29];
    }
    let t17;
    if ($[30] !== equipment.description) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t16,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-slate-50",
                    children: equipment.description
                }, void 0, false, {
                    fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                    lineNumber: 172,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 172,
            columnNumber: 11
        }, this);
        $[30] = equipment.description;
        $[31] = t17;
    } else {
        t17 = $[31];
    }
    let t18;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-sm font-medium text-slate-400 mb-2",
            children: "リスクレベル"
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 180,
            columnNumber: 11
        }, this);
        $[32] = t18;
    } else {
        t18 = $[32];
    }
    let t19;
    if ($[33] !== info.description) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t18,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-slate-300",
                    children: info.description
                }, void 0, false, {
                    fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                    lineNumber: 187,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 187,
            columnNumber: 11
        }, this);
        $[33] = info.description;
        $[34] = t19;
    } else {
        t19 = $[34];
    }
    let t20;
    if ($[35] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-sm font-medium text-slate-400 mb-2",
            children: "位置情報"
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 195,
            columnNumber: 11
        }, this);
        $[35] = t20;
    } else {
        t20 = $[35];
    }
    let t21;
    if ($[36] === Symbol.for("react.memo_cache_sentinel")) {
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-slate-400",
            children: "X:"
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 202,
            columnNumber: 11
        }, this);
        $[36] = t21;
    } else {
        t21 = $[36];
    }
    let t22;
    if ($[37] !== equipment.bbox.x) {
        t22 = equipment.bbox.x.toFixed(1);
        $[37] = equipment.bbox.x;
        $[38] = t22;
    } else {
        t22 = $[38];
    }
    let t23;
    if ($[39] !== t22) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-slate-900/50 p-2 rounded",
            children: [
                t21,
                " ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-slate-50",
                    children: [
                        t22,
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                    lineNumber: 217,
                    columnNumber: 66
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 217,
            columnNumber: 11
        }, this);
        $[39] = t22;
        $[40] = t23;
    } else {
        t23 = $[40];
    }
    let t24;
    if ($[41] === Symbol.for("react.memo_cache_sentinel")) {
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-slate-400",
            children: "Y:"
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 225,
            columnNumber: 11
        }, this);
        $[41] = t24;
    } else {
        t24 = $[41];
    }
    let t25;
    if ($[42] !== equipment.bbox.y) {
        t25 = equipment.bbox.y.toFixed(1);
        $[42] = equipment.bbox.y;
        $[43] = t25;
    } else {
        t25 = $[43];
    }
    let t26;
    if ($[44] !== t25) {
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-slate-900/50 p-2 rounded",
            children: [
                t24,
                " ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-slate-50",
                    children: [
                        t25,
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                    lineNumber: 240,
                    columnNumber: 66
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 240,
            columnNumber: 11
        }, this);
        $[44] = t25;
        $[45] = t26;
    } else {
        t26 = $[45];
    }
    let t27;
    if ($[46] === Symbol.for("react.memo_cache_sentinel")) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-slate-400",
            children: "幅:"
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 248,
            columnNumber: 11
        }, this);
        $[46] = t27;
    } else {
        t27 = $[46];
    }
    let t28;
    if ($[47] !== equipment.bbox.width) {
        t28 = equipment.bbox.width.toFixed(1);
        $[47] = equipment.bbox.width;
        $[48] = t28;
    } else {
        t28 = $[48];
    }
    let t29;
    if ($[49] !== t28) {
        t29 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-slate-900/50 p-2 rounded",
            children: [
                t27,
                " ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-slate-50",
                    children: [
                        t28,
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                    lineNumber: 263,
                    columnNumber: 66
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 263,
            columnNumber: 11
        }, this);
        $[49] = t28;
        $[50] = t29;
    } else {
        t29 = $[50];
    }
    let t30;
    if ($[51] === Symbol.for("react.memo_cache_sentinel")) {
        t30 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-slate-400",
            children: "高さ:"
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 271,
            columnNumber: 11
        }, this);
        $[51] = t30;
    } else {
        t30 = $[51];
    }
    let t31;
    if ($[52] !== equipment.bbox.height) {
        t31 = equipment.bbox.height.toFixed(1);
        $[52] = equipment.bbox.height;
        $[53] = t31;
    } else {
        t31 = $[53];
    }
    let t32;
    if ($[54] !== t31) {
        t32 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-slate-900/50 p-2 rounded",
            children: [
                t30,
                " ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-slate-50",
                    children: [
                        t31,
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                    lineNumber: 286,
                    columnNumber: 66
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 286,
            columnNumber: 11
        }, this);
        $[54] = t31;
        $[55] = t32;
    } else {
        t32 = $[55];
    }
    let t33;
    if ($[56] !== t23 || $[57] !== t26 || $[58] !== t29 || $[59] !== t32) {
        t33 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: [
                t20,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-2 gap-2 text-sm font-mono",
                    children: [
                        t23,
                        t26,
                        t29,
                        t32
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                    lineNumber: 294,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 294,
            columnNumber: 11
        }, this);
        $[56] = t23;
        $[57] = t26;
        $[58] = t29;
        $[59] = t32;
        $[60] = t33;
    } else {
        t33 = $[60];
    }
    let t34;
    if ($[61] !== t17 || $[62] !== t19 || $[63] !== t33) {
        t34 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6 space-y-4",
            children: [
                t17,
                t19,
                t33
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 305,
            columnNumber: 11
        }, this);
        $[61] = t17;
        $[62] = t19;
        $[63] = t33;
        $[64] = t34;
    } else {
        t34 = $[64];
    }
    let t35;
    if ($[65] !== onClose) {
        t35 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-4 bg-slate-900/50 border-t border-slate-700",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: onClose,
                className: "w-full px-4 py-3 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors",
                children: "閉じる"
            }, void 0, false, {
                fileName: "[project]/app/components/EquipmentDetailModal.tsx",
                lineNumber: 315,
                columnNumber: 74
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 315,
            columnNumber: 11
        }, this);
        $[65] = onClose;
        $[66] = t35;
    } else {
        t35 = $[66];
    }
    let t36;
    if ($[67] !== t15 || $[68] !== t34 || $[69] !== t35) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full max-w-md bg-slate-800 rounded-t-2xl sm:rounded-2xl shadow-2xl overflow-hidden",
            onClick: _EquipmentDetailModalDivOnClick,
            children: [
                t15,
                t34,
                t35
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 323,
            columnNumber: 11
        }, this);
        $[67] = t15;
        $[68] = t34;
        $[69] = t35;
        $[70] = t36;
    } else {
        t36 = $[70];
    }
    let t37;
    if ($[71] !== onClose || $[72] !== t36) {
        t37 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/50 backdrop-blur-sm",
            onClick: onClose,
            children: t36
        }, void 0, false, {
            fileName: "[project]/app/components/EquipmentDetailModal.tsx",
            lineNumber: 333,
            columnNumber: 11
        }, this);
        $[71] = onClose;
        $[72] = t36;
        $[73] = t37;
    } else {
        t37 = $[73];
    }
    return t37;
}
_c = EquipmentDetailModal;
function _EquipmentDetailModalDivOnClick(e) {
    return e.stopPropagation();
}
var _c;
__turbopack_context__.k.register(_c, "EquipmentDetailModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/LoadingIndicator.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LoadingIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
function LoadingIndicator(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(17);
    if ($[0] !== "87c12a1a0ec1d5017f0dfd773142e7bba4e790ce56f3e3f07d320925932049a9") {
        for(let $i = 0; $i < 17; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "87c12a1a0ec1d5017f0dfd773142e7bba4e790ce56f3e3f07d320925932049a9";
    }
    const { message, progress } = t0;
    let t1;
    let t2;
    let t3;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 rounded-full border-4 border-sky-500/20"
        }, void 0, false, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 29,
            columnNumber: 10
        }, this);
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-4 rounded-full border-4 border-sky-500/30"
        }, void 0, false, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 30,
            columnNumber: 10
        }, this);
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-8 rounded-full border-4 border-sky-500/40"
        }, void 0, false, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 31,
            columnNumber: 10
        }, this);
        $[1] = t1;
        $[2] = t2;
        $[3] = t3;
    } else {
        t1 = $[1];
        t2 = $[2];
        t3 = $[3];
    }
    let t4;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "absolute inset-0 animate-spin",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute top-1/2 left-1/2 w-16 h-1 bg-gradient-to-r from-transparent via-sky-500 to-transparent transform -translate-x-1/2 -translate-y-1/2 origin-left"
            }, void 0, false, {
                fileName: "[project]/app/components/LoadingIndicator.tsx",
                lineNumber: 42,
                columnNumber: 57
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 42,
            columnNumber: 10
        }, this);
        $[4] = t4;
    } else {
        t4 = $[4];
    }
    let t5;
    if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "relative w-32 h-32 mx-auto mb-6",
            children: [
                t1,
                t2,
                t3,
                t4,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 flex items-center justify-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-4xl animate-pulse",
                        children: "🔍"
                    }, void 0, false, {
                        fileName: "[project]/app/components/LoadingIndicator.tsx",
                        lineNumber: 49,
                        columnNumber: 142
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/LoadingIndicator.tsx",
                    lineNumber: 49,
                    columnNumber: 75
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 49,
            columnNumber: 10
        }, this);
        $[5] = t5;
    } else {
        t5 = $[5];
    }
    let t6;
    if ($[6] !== message) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-xl font-bold text-slate-50 mb-2",
            children: message
        }, void 0, false, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 56,
            columnNumber: 10
        }, this);
        $[6] = message;
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t7;
    if ($[8] !== progress) {
        t7 = progress !== undefined && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-64 mx-auto",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-2 bg-slate-800 rounded-full overflow-hidden",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-full bg-sky-500 transition-all duration-300",
                        style: {
                            width: `${progress}%`
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/components/LoadingIndicator.tsx",
                        lineNumber: 64,
                        columnNumber: 129
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/LoadingIndicator.tsx",
                    lineNumber: 64,
                    columnNumber: 66
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-slate-400 mt-2",
                    children: [
                        Math.round(progress),
                        "%"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/LoadingIndicator.tsx",
                    lineNumber: 66,
                    columnNumber: 20
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 64,
            columnNumber: 36
        }, this);
        $[8] = progress;
        $[9] = t7;
    } else {
        t7 = $[9];
    }
    let t8;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-sm text-slate-400 mt-4 max-w-md",
            children: "AI が画像を分析しています..."
        }, void 0, false, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 74,
            columnNumber: 10
        }, this);
        $[10] = t8;
    } else {
        t8 = $[10];
    }
    let t9;
    if ($[11] !== t6 || $[12] !== t7) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center",
            children: [
                t5,
                t6,
                t7,
                t8
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 81,
            columnNumber: 10
        }, this);
        $[11] = t6;
        $[12] = t7;
        $[13] = t9;
    } else {
        t9 = $[13];
    }
    let t10;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            id: "e76c9e8223b27a15",
            children: "@keyframes spin{0%{transform:rotate(0)}to{transform:rotate(360deg)}}"
        }, void 0, false, void 0, this);
        $[14] = t10;
    } else {
        t10 = $[14];
    }
    let t11;
    if ($[15] !== t9) {
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-sm",
            children: [
                t9,
                t10
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/LoadingIndicator.tsx",
            lineNumber: 97,
            columnNumber: 11
        }, this);
        $[15] = t9;
        $[16] = t11;
    } else {
        t11 = $[16];
    }
    return t11;
}
_c = LoadingIndicator;
var _c;
__turbopack_context__.k.register(_c, "LoadingIndicator");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/ErrorMessage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ErrorMessage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
'use client';
;
;
function ErrorMessage(t0) {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(20);
    if ($[0] !== "cabfbb66c9530298fd0c2367d2932a5c8785bc866cf220fe25f78d886b89f5af") {
        for(let $i = 0; $i < 20; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "cabfbb66c9530298fd0c2367d2932a5c8785bc866cf220fe25f78d886b89f5af";
    }
    const { message, onRetry } = t0;
    const getErrorInfo = _ErrorMessageGetErrorInfo;
    let t1;
    if ($[1] !== message) {
        t1 = getErrorInfo(message);
        $[1] = message;
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const errorInfo = t1;
    let t2;
    if ($[3] !== errorInfo.icon) {
        t2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: "text-4xl",
            children: errorInfo.icon
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.tsx",
            lineNumber: 37,
            columnNumber: 10
        }, this);
        $[3] = errorInfo.icon;
        $[4] = t2;
    } else {
        t2 = $[4];
    }
    let t3;
    if ($[5] !== errorInfo.title) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            className: "text-xl font-bold text-slate-50",
            children: errorInfo.title
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.tsx",
            lineNumber: 45,
            columnNumber: 10
        }, this);
        $[5] = errorInfo.title;
        $[6] = t3;
    } else {
        t3 = $[6];
    }
    let t4;
    if ($[7] !== t2 || $[8] !== t3) {
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6 bg-red-500/10",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3 mb-2",
                children: [
                    t2,
                    t3
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ErrorMessage.tsx",
                lineNumber: 53,
                columnNumber: 45
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.tsx",
            lineNumber: 53,
            columnNumber: 10
        }, this);
        $[7] = t2;
        $[8] = t3;
        $[9] = t4;
    } else {
        t4 = $[9];
    }
    let t5;
    if ($[10] !== message) {
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-slate-200 leading-relaxed",
                children: message
            }, void 0, false, {
                fileName: "[project]/app/components/ErrorMessage.tsx",
                lineNumber: 62,
                columnNumber: 31
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.tsx",
            lineNumber: 62,
            columnNumber: 10
        }, this);
        $[10] = message;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    let t6;
    if ($[12] !== onRetry) {
        t6 = onRetry && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            onClick: onRetry,
            className: "flex-1 px-4 py-3 bg-sky-500 hover:bg-sky-600 text-white font-medium rounded-lg transition-colors flex items-center justify-center gap-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                    }, void 0, false, {
                        fileName: "[project]/app/components/ErrorMessage.tsx",
                        lineNumber: 70,
                        columnNumber: 274
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/ErrorMessage.tsx",
                    lineNumber: 70,
                    columnNumber: 195
                }, this),
                "再試行"
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/ErrorMessage.tsx",
            lineNumber: 70,
            columnNumber: 21
        }, this);
        $[12] = onRetry;
        $[13] = t6;
    } else {
        t6 = $[13];
    }
    let t7;
    if ($[14] !== t6) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "p-4 bg-slate-900/50 border-t border-slate-700 flex gap-3",
            children: t6
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.tsx",
            lineNumber: 78,
            columnNumber: 10
        }, this);
        $[14] = t6;
        $[15] = t7;
    } else {
        t7 = $[15];
    }
    let t8;
    if ($[16] !== t4 || $[17] !== t5 || $[18] !== t7) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-sm",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-md bg-slate-800 rounded-2xl shadow-2xl overflow-hidden border-l-4 border-red-500",
                children: [
                    t4,
                    t5,
                    t7
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/ErrorMessage.tsx",
                lineNumber: 86,
                columnNumber: 116
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/ErrorMessage.tsx",
            lineNumber: 86,
            columnNumber: 10
        }, this);
        $[16] = t4;
        $[17] = t5;
        $[18] = t7;
        $[19] = t8;
    } else {
        t8 = $[19];
    }
    return t8;
}
_c = ErrorMessage;
function _ErrorMessageGetErrorInfo(msg) {
    if (msg.includes("\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF")) {
        return {
            icon: "\uD83D\uDCE1",
            title: "\u30CD\u30C3\u30C8\u30EF\u30FC\u30AF\u30A8\u30E9\u30FC"
        };
    } else {
        if (msg.includes("\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8")) {
            return {
                icon: "\u23F1\uFE0F",
                title: "\u30BF\u30A4\u30E0\u30A2\u30A6\u30C8"
            };
        } else {
            if (msg.includes("\u8A8D\u8B58\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F")) {
                return {
                    icon: "\uD83D\uDD0D",
                    title: "\u6A5F\u5668\u672A\u691C\u51FA"
                };
            } else {
                if (msg.includes("\u30AB\u30E1\u30E9")) {
                    return {
                        icon: "\uD83D\uDCF7",
                        title: "\u30AB\u30E1\u30E9\u30A8\u30E9\u30FC"
                    };
                } else {
                    if (msg.includes("\u30B5\u30A4\u30BA")) {
                        return {
                            icon: "\uD83D\uDCCF",
                            title: "\u30D5\u30A1\u30A4\u30EB\u30B5\u30A4\u30BA\u30A8\u30E9\u30FC"
                        };
                    } else {
                        if (msg.includes("\u5F62\u5F0F")) {
                            return {
                                icon: "\uD83D\uDCC4",
                                title: "\u30D5\u30A1\u30A4\u30EB\u5F62\u5F0F\u30A8\u30E9\u30FC"
                            };
                        } else {
                            return {
                                icon: "\u26A0\uFE0F",
                                title: "\u30A8\u30E9\u30FC"
                            };
                        }
                    }
                }
            }
        }
    }
}
var _c;
__turbopack_context__.k.register(_c, "ErrorMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API関数
 */ __turbopack_context__.s([
    "getSignedUploadUrl",
    ()=>getSignedUploadUrl,
    "pollAnalysisStatus",
    ()=>pollAnalysisStatus,
    "uploadAndAnalyze",
    ()=>uploadAndAnalyze,
    "uploadToS3",
    ()=>uploadToS3
]);
async function getSignedUploadUrl(contentType) {
    const response = await fetch('/api/upload-url', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            contentType
        })
    });
    if (!response.ok) {
        throw new Error('署名付きURLの取得に失敗しました');
    }
    return response.json();
}
async function uploadToS3(signedUrl, file, onProgress) {
    return new Promise((resolve, reject)=>{
        const xhr = new XMLHttpRequest();
        // プログレス監視
        if (onProgress) {
            xhr.upload.addEventListener('progress', (event)=>{
                if (event.lengthComputable) {
                    const progress = event.loaded / event.total * 100;
                    onProgress(progress);
                }
            });
        }
        xhr.addEventListener('load', ()=>{
            if (xhr.status === 200) {
                resolve();
            } else {
                reject(new Error(`アップロード失敗: ${xhr.status}`));
            }
        });
        xhr.addEventListener('error', ()=>{
            reject(new Error('ネットワークエラーが発生しました'));
        });
        xhr.addEventListener('abort', ()=>{
            reject(new Error('アップロードがキャンセルされました'));
        });
        xhr.open('PUT', signedUrl);
        xhr.setRequestHeader('Content-Type', file.type);
        xhr.send(file);
    });
}
async function pollAnalysisStatus(imageKey, maxAttempts = 30, intervalMs = 1000) {
    for(let attempt = 0; attempt < maxAttempts; attempt++){
        const response = await fetch(`/api/analyze-status?key=${encodeURIComponent(imageKey)}`);
        if (!response.ok) {
            throw new Error('分析ステータスの確認に失敗しました');
        }
        const data = await response.json();
        if (data.status === 'completed') {
            return {
                imageKey,
                equipment: data.result.equipment || [],
                timestamp: Date.now(),
                status: 'completed'
            };
        }
        if (data.status === 'failed') {
            throw new Error(data.error || '分析に失敗しました');
        }
        // 次のポーリングまで待機
        await new Promise((resolve)=>setTimeout(resolve, intervalMs));
    }
    throw new Error('分析がタイムアウトしました。もう一度お試しください');
}
async function uploadAndAnalyze(file, onProgress) {
    // 1. 署名付きURL取得
    const { uploadUrl, key } = await getSignedUploadUrl(file.type);
    // 2. S3にアップロード
    await uploadToS3(uploadUrl, file, onProgress);
    // 3. 分析完了を待機
    const result = await pollAnalysisStatus(key);
    return result;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ImageInputSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ImageInputSelector.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$CameraCapture$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/CameraCapture.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$FileUpload$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/FileUpload.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ImagePreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ImagePreview.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$OverlayRenderer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/OverlayRenderer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$EquipmentDetailModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/EquipmentDetailModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$LoadingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/LoadingIndicator.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
function Home() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(48);
    if ($[0] !== "c2f1c2c3027c310bd703ef468446793eda6ac6320f9af424f2f61942c458a752") {
        for(let $i = 0; $i < 48; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "c2f1c2c3027c310bd703ef468446793eda6ac6320f9af424f2f61942c458a752";
    }
    const [status, setStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("idle");
    const [inputMode, setInputMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("upload");
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            blob: null,
            url: null
        };
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [selectedImage, setSelectedImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    const [analysisResult, setAnalysisResult] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [selectedEquipment, setSelectedEquipment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [uploadProgress, setUploadProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "Home[handleImageSelect]": (blob)=>{
                const url = URL.createObjectURL(blob);
                setSelectedImage({
                    blob,
                    url
                });
                setStatus("preview");
                setError(null);
            }
        })["Home[handleImageSelect]"];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const handleImageSelect = t1;
    let t2;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = ({
            "Home[handleError]": (error_0)=>{
                console.error("\u30A8\u30E9\u30FC:", error_0);
                setError(error_0.message);
                setStatus("error");
            }
        })["Home[handleError]"];
        $[3] = t2;
    } else {
        t2 = $[3];
    }
    const handleError = t2;
    let t3;
    if ($[4] !== selectedImage.url) {
        t3 = ({
            "Home[handleRetake]": ()=>{
                if (selectedImage.url) {
                    URL.revokeObjectURL(selectedImage.url);
                }
                setSelectedImage({
                    blob: null,
                    url: null
                });
                setAnalysisResult(null);
                setError(null);
                setStatus("idle");
                setUploadProgress(0);
            }
        })["Home[handleRetake]"];
        $[4] = selectedImage.url;
        $[5] = t3;
    } else {
        t3 = $[5];
    }
    const handleRetake = t3;
    let t4;
    if ($[6] !== selectedImage.blob) {
        t4 = ({
            "Home[handleConfirm]": async ()=>{
                if (!selectedImage.blob) {
                    return;
                }
                ;
                try {
                    setStatus("uploading");
                    setUploadProgress(0);
                    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadAndAnalyze"])(selectedImage.blob, {
                        "Home[handleConfirm > uploadAndAnalyze()]": (progress)=>{
                            setUploadProgress(progress);
                            if (progress >= 100) {
                                setStatus("analyzing");
                            }
                        }
                    }["Home[handleConfirm > uploadAndAnalyze()]"]);
                    setAnalysisResult(result);
                    setStatus("completed");
                } catch (t5) {
                    const error_1 = t5;
                    handleError(error_1);
                }
            }
        })["Home[handleConfirm]"];
        $[6] = selectedImage.blob;
        $[7] = t4;
    } else {
        t4 = $[7];
    }
    const handleConfirm = t4;
    let t5;
    if ($[8] !== handleRetake || $[9] !== selectedImage.blob || $[10] !== status) {
        t5 = ({
            "Home[handleRetry]": ()=>{
                setError(null);
                if (status === "error" && selectedImage.blob) {
                    setStatus("preview");
                } else {
                    handleRetake();
                }
            }
        })["Home[handleRetry]"];
        $[8] = handleRetake;
        $[9] = selectedImage.blob;
        $[10] = status;
        $[11] = t5;
    } else {
        t5 = $[11];
    }
    const handleRetry = t5;
    let t6;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = ({
            "Home[handleEquipmentClick]": (equipment)=>{
                setSelectedEquipment(equipment);
            }
        })["Home[handleEquipmentClick]"];
        $[12] = t6;
    } else {
        t6 = $[12];
    }
    const handleEquipmentClick = t6;
    let t7;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = ({
            "Home[handleCloseModal]": ()=>{
                setSelectedEquipment(null);
            }
        })["Home[handleCloseModal]"];
        $[13] = t7;
    } else {
        t7 = $[13];
    }
    const handleCloseModal = t7;
    let t8;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: "p-4 bg-slate-900/50 border-b border-slate-800",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: "text-2xl font-bold text-center",
                    children: "🎬 技術局長"
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 175,
                    columnNumber: 76
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-slate-400 text-center mt-1",
                    children: "放送機器安全確認アプリ"
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 175,
                    columnNumber: 135
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 175,
            columnNumber: 10
        }, this);
        $[14] = t8;
    } else {
        t8 = $[14];
    }
    let t9;
    if ($[15] !== inputMode || $[16] !== status) {
        t9 = status === "idle" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 flex flex-col p-4 gap-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ImageInputSelector$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    mode: inputMode,
                    onModeChange: setInputMode
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 182,
                    columnNumber: 79
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-hidden",
                    children: inputMode === "camera" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$CameraCapture$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onCapture: handleImageSelect,
                        onError: handleError
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 182,
                        columnNumber: 212
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$FileUpload$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onFileSelect: handleImageSelect,
                        onError: handleError
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 182,
                        columnNumber: 284
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 182,
                    columnNumber: 146
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 182,
            columnNumber: 31
        }, this);
        $[15] = inputMode;
        $[16] = status;
        $[17] = t9;
    } else {
        t9 = $[17];
    }
    let t10;
    if ($[18] !== handleConfirm || $[19] !== handleRetake || $[20] !== selectedImage.url || $[21] !== status) {
        t10 = status === "preview" && selectedImage.url && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ImagePreview$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            imageUrl: selectedImage.url,
            onConfirm: handleConfirm,
            onRetake: handleRetake
        }, void 0, false, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 191,
            columnNumber: 56
        }, this);
        $[18] = handleConfirm;
        $[19] = handleRetake;
        $[20] = selectedImage.url;
        $[21] = status;
        $[22] = t10;
    } else {
        t10 = $[22];
    }
    let t11;
    if ($[23] !== analysisResult || $[24] !== handleRetake || $[25] !== selectedImage.url || $[26] !== status) {
        t11 = status === "completed" && selectedImage.url && analysisResult && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1 flex flex-col",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 overflow-hidden",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$OverlayRenderer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        imageUrl: selectedImage.url,
                        equipment: analysisResult.equipment,
                        onEquipmentClick: handleEquipmentClick
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 202,
                        columnNumber: 154
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 202,
                    columnNumber: 114
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-4 bg-slate-800/90 border-t border-slate-700",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: handleRetake,
                        className: "w-full px-6 py-3 bg-slate-700 hover:bg-slate-600 text-slate-50 font-medium rounded-lg transition-colors",
                        children: "🔄 新しい画像を分析"
                    }, void 0, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 202,
                        columnNumber: 348
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 202,
                    columnNumber: 285
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 202,
            columnNumber: 76
        }, this);
        $[23] = analysisResult;
        $[24] = handleRetake;
        $[25] = selectedImage.url;
        $[26] = status;
        $[27] = t11;
    } else {
        t11 = $[27];
    }
    let t12;
    if ($[28] !== t10 || $[29] !== t11 || $[30] !== t9) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
            className: "flex-1 flex flex-col overflow-hidden",
            children: [
                t9,
                t10,
                t11
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 213,
            columnNumber: 11
        }, this);
        $[28] = t10;
        $[29] = t11;
        $[30] = t9;
        $[31] = t12;
    } else {
        t12 = $[31];
    }
    let t13;
    if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
            className: "p-2 bg-slate-900/50 border-t border-slate-800 text-center text-xs text-slate-500",
            children: "MBS Hackathon 2026 - C班"
        }, void 0, false, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 223,
            columnNumber: 11
        }, this);
        $[32] = t13;
    } else {
        t13 = $[32];
    }
    let t14;
    if ($[33] !== status || $[34] !== uploadProgress) {
        t14 = (status === "uploading" || status === "analyzing") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$LoadingIndicator$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            message: status === "uploading" ? "\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u4E2D..." : "AI\u5206\u6790\u4E2D...",
            progress: status === "uploading" ? uploadProgress : undefined
        }, void 0, false, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 230,
            columnNumber: 65
        }, this);
        $[33] = status;
        $[34] = uploadProgress;
        $[35] = t14;
    } else {
        t14 = $[35];
    }
    let t15;
    if ($[36] !== error || $[37] !== handleRetry || $[38] !== status) {
        t15 = status === "error" && error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            message: error,
            onRetry: handleRetry
        }, void 0, false, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 239,
            columnNumber: 42
        }, this);
        $[36] = error;
        $[37] = handleRetry;
        $[38] = status;
        $[39] = t15;
    } else {
        t15 = $[39];
    }
    const t16 = selectedEquipment !== null;
    let t17;
    if ($[40] !== selectedEquipment || $[41] !== t16) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$EquipmentDetailModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            equipment: selectedEquipment,
            isOpen: t16,
            onClose: handleCloseModal
        }, void 0, false, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 250,
            columnNumber: 11
        }, this);
        $[40] = selectedEquipment;
        $[41] = t16;
        $[42] = t17;
    } else {
        t17 = $[42];
    }
    let t18;
    if ($[43] !== t12 || $[44] !== t14 || $[45] !== t15 || $[46] !== t17) {
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "w-full h-screen bg-slate-950 text-slate-50 flex flex-col",
            children: [
                t8,
                t12,
                t13,
                t14,
                t15,
                t17
            ]
        }, void 0, true, {
            fileName: "[project]/app/page.tsx",
            lineNumber: 259,
            columnNumber: 11
        }, this);
        $[43] = t12;
        $[44] = t14;
        $[45] = t15;
        $[46] = t17;
        $[47] = t18;
    } else {
        t18 = $[47];
    }
    return t18;
}
_s(Home, "No3hEayMbOJgVXZp45/4HZlwLiE=");
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_3424453f._.js.map