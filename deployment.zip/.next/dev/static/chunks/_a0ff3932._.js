(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_956a0d3a._.js",
  "static/chunks/node_modules_next_dist_compiled_react-dom_1e674e59._.js",
  "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_9212ccad._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_1dd7fb59.js",
  "static/chunks/node_modules_next_dist_compiled_a0e4c7b4._.js",
  "static/chunks/node_modules_next_dist_client_17643121._.js",
  "static/chunks/node_modules_next_dist_f3530cac._.js",
  "static/chunks/node_modules_@swc_helpers_cjs_d80fb378._.js"
],
    source: "entry"
});
