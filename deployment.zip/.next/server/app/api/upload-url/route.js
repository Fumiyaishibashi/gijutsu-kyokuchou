var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/upload-url/route.js")
R.c("server/chunks/[root-of-the-server]__c438f451._.js")
R.c("server/chunks/node_modules_@smithy_b35f632b._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/[root-of-the-server]__b18dcb6f._.js")
R.c("server/chunks/_next-internal_server_app_api_upload-url_route_actions_a81582ff.js")
R.m(65759)
module.exports=R.m(65759).exports
